# E-Commerce Web Application

This is a simple E-Commerce Web Application built using HTML, CSS, and JavaScript.

## Features
- Product listing
- Add to cart functionality
- Dynamic cart update

## Technologies Used
- HTML
- CSS
- JavaScript

## How to Run
Open index.html in any browser.
